package com.shop.shop_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
