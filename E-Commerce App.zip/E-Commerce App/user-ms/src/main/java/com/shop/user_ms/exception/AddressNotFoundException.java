package com.shop.user_ms.exception;

public class AddressNotFoundException extends Exception{
    public AddressNotFoundException(String message) {
        super(message);
    }
}
