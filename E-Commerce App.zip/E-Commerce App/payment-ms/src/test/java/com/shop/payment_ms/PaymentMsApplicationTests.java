package com.shop.payment_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
