package com.shop.offers_ms.exception;

public class OfferNotFoundException extends Exception {
    public OfferNotFoundException(String message) {
        super(message);
    }
}
