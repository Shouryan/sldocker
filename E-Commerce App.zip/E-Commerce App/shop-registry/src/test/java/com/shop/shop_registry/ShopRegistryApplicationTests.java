package com.shop.shop_registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
